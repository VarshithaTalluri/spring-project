package org.niit.autowiringspring;

public class Students
{
private Student st1;
private Student st2;
private Student st3;
public Student getSt1() {
	return st1;
}
public void setSt1(Student st1) {
	this.st1 = st1;
}
public Student getSt2() {
	return st2;
}
public void setSt2(Student st2) {
	this.st2 = st2;
}
public Student getSt3() {
	return st3;
}
public void setSt3(Student st3) {
	this.st3 = st3;
}
@Override
public String toString() {
	return "Students [st1=" + st1 + ", st2=" + st2 + ", st3=" + st3 + "]";
}

}
