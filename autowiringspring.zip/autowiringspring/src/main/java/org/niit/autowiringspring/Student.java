package org.niit.autowiringspring;

public class Student 
{
 private String Sname;
 private String age;
public String getSname() {
	return Sname;
}
public void setSname(String sname) {
	Sname = sname;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
 
}
