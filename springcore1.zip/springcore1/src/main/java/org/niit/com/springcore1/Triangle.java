package org.niit.com.springcore1;

public class Triangle implements Shape
{

	public void draw()
	{
		System.out.println("this is triangle method");
	}

}
