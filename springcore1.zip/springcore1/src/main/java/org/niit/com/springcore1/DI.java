package org.niit.com.springcore1;

public class DI
{
public static void main(String args[])
{
	App obj=new App();
	obj.draw(new Triangle());
}
}
