package org.niit.com.springcore1;

public interface Shape
{
 void draw();
}
