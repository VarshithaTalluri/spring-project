package org.niit.com.springcore1;
public class App 
{
   	public void draw(Shape shape)
    	{
         shape.draw();
    	}
   
}
