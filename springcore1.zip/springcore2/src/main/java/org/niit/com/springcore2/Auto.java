package org.niit.com.springcore2;

import org.springframework.stereotype.Component;

@Component
public class Auto implements Vehicle
{
	public void move()
	{
System.out.println("this is auto method ");

	}
}
