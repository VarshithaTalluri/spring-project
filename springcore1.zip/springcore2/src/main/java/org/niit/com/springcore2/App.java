package org.niit.com.springcore2;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
       Vehicle obj=(Vehicle)ac.getBean("auto");
       obj.move();
    }
}
