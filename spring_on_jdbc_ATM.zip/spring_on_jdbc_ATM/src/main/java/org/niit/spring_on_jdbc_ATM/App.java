package org.niit.spring_on_jdbc_ATM;

import controller.Controller;
public class App
{
	public static void main(String args[])
	{
      new Controller();
    } 
}