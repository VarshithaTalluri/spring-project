package model;

public class Customer
{
  private String cname,city;
  private Long accnum;
  private int pin,bal;
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public Long getAccnum() {
	return accnum;
}
public void setAccnum(Long accnum) {
	this.accnum = accnum;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getPin() {
	return pin;
}
public void setPin(int pin) {
	this.pin = pin;
}
public int getBal() {
	return bal;
}
public void setBal(int bal) {
	this.bal = bal;
}
  
}
