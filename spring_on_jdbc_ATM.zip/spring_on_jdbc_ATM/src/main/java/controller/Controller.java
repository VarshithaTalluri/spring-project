package controller;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.AtmImplementation;
import model.Customer;
public class Controller 
{
	 Scanner s=new Scanner(System.in);
	 Long AccountNumber;
	ApplicationContext ac=null;
	public void  Constructor()
	{
		ac=new ClassPathXmlApplicationContext("spring.xml");
		pin();
	}
	 public Customer addaccount()
	 {   
		 Customer customer=new Customer();
		 System.out.println("Enter your Name");
		 customer.setCname(s.next());
		 System.out.println("Enter your accnumber");
		 AccountNumber=s.nextLong();
		 customer.setAccnum(AccountNumber);
		 System.out.println("Enter your city");
		 customer.setCity(s.next());
		 System.out.println("Enter Pin");
		 customer.setPin(s.nextInt());
		 return customer;
	 }
	 public void pin()
	 {
		 Customer customer=new Customer();
		 System.out.println("1.existing user");
		 System.out.println("2.new user");
		 System.out.println("choose option");
		 int opt=s.nextInt();
		 if(opt==1)
		 {
			 System.out.println("enter your account number");
			 AccountNumber=s.nextLong();
			 customer.setAccnum(AccountNumber);
			 System.out.println("enter pin");
			customer.setPin(s.nextInt());
			boolean b=new AtmImplementation().validation(customer);
			if(b)
			{
				options();
			}
			else
			{
				pin();
			}
		 }
		 else if(opt==2)
		 {
			 customer=addaccount();
			 boolean b=new  AtmImplementation().addaccount(customer);
			 if(b)
			 {
				 System.out.println("account created");
			 }
			 else
			 {
				 System.out.println("account not created,check deatils");
			 }
		 }
		 
	 }	 
     public void options()
     {
    	 int opt=0;
    	 Customer customer =new Customer();
    	 System.out.println("1.Add Account");
    	 System.out.println("2.Deposite Amount");
    	 System.out.println("3.balance enquiry");
    	 do
    	 {
    		 System.out.println("Select Option");
    		 opt=s.nextInt();
    		 if(opt==1)
    		 {
    			 customer=addaccount();
    			 boolean b=new  AtmImplementation().addaccount(customer);
    			 if(b)
    			 {
    				 System.out.println("account created");
    			 }
    			 else
    			 {
    				 System.out.println("account not created,check deatils");
    			 }
    		 }
    		 else if(opt==2)
    		 {
    			 
    			 customer.setAccnum(AccountNumber);
    			 System.out.println("Enter Amount To Deposite");
    			 customer.setBal(s.nextInt());
    			 customer.setBal(new AtmImplementation().deposite(customer));
    			 System.out.println("Account Balance:"+customer.getBal());
    		 }
    		 else if(opt==3)
    		 {
    			 customer.setAccnum(AccountNumber);
    			 System.out.println("know your account balance");
    			 customer.setBal(new AtmImplementation().balEnquiry(customer));
    			 System.out.println("Account Balance:"+customer.getBal());
    		 }
    	 }
    	 while(opt!=0);
     }
}
