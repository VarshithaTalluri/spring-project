package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import model.Customer;

public class AtmImplementation implements AtmInterface
{
	 static Connection con=null;
		
	public static Connection getconnection()
	{
		try
		{
	     Class.forName("com.mysql.jdbc.Driver");
	     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha","root","varshitha@947");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
   
	public boolean addaccount(Customer customer)
	{
		int i=0;
		boolean b=false;
		{
			try 
			{
		PreparedStatement pstmt=con.prepareStatement("insert into bank values(?,?,?,?)");
		pstmt.setString(1, customer.getCname());
		pstmt.setLong(2, customer.getAccnum());
		pstmt.setString(3, customer.getCity());
		pstmt.setInt(4, customer.getPin());
		pstmt.setInt(5, customer.getBal());
		i=pstmt.executeUpdate();
		if(i>0) 
		    {
			b=true;
	           }
		    }
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		return b;
	}

	public boolean validation(Customer customer)
	{
		boolean b=false;
		ResultSet rs=null;
		int i=0;
		try
		{
		Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select pin from bank where pin='"+customer.getPin()+"'");
		if(rs.next())
		{
			System.out.println("valid pin");
		}
		else
		{
			System.out.println("invalid pin,please enter correct pin");
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}

	public int deposite(Customer customer)
	{
		
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select bal from bank where accnum='"+customer.getAccnum()+"'");			
			if(rs.next())
			{
				customer.setBal(customer.getBal()+rs.getInt(1));
				int i=st.executeUpdate("update bank set bal='"+customer.getBal()+"' where accnum='"+customer.getAccnum()+"'");
				if(i>0)
				{
					return customer.getBal();
				}
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return customer.getBal();
		
		}

	public int balEnquiry(Customer customer) 
	{
		ResultSet rs=null;
		try
		{
		Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select bal from bank where bal='"+customer.getBal()+"'");
		if(rs.next())
		{
			customer.setBal(Integer.parseInt(rs.getString(1)));
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}	
		return customer.getBal();
	}

}


