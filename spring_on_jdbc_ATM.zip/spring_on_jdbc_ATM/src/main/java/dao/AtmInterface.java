package dao;

import model.Customer;

public interface AtmInterface
{
 public boolean addaccount(Customer customer);
 public boolean validation(Customer customer);
 public int deposite(Customer customer);
 public int balEnquiry(Customer customer);
}
