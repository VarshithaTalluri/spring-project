package org.niit.com.springcore2;

public interface Vehicle
{
 void move();
}
