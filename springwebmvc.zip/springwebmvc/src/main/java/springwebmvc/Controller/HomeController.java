package springwebmvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.usermodel;

@Controller
public class HomeController
{
	@RequestMapping("/reqadd")
 public ModelAndView  add(HttpServletRequest req,HttpServletResponse res)
 {
		int a=Integer.parseInt(req.getParameter("t1"));
		int b=Integer.parseInt(req.getParameter("t2"));
		int result=a+b;
		ModelAndView mav=new ModelAndView();
		mav.addObject("result",result);
		mav.setViewName("display.jsp");
	    return mav;
 }
	@RequestMapping("/reqreg")
	public ModelAndView reg(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mav=new ModelAndView();
	  usermodel um=new usermodel();
	  um.setName(req.getParameter("t1"));
	  um.setMobile(Integer.parseInt(req.getParameter("t2")));
	  um.setPassword(req.getParameter("t3"));
	  um.setCity(req.getParameter("t4"));
	  um.setGender(req.getParameter("t5"));
	  mav.addObject("result",um);
	  mav.setViewName("display.jsp");
	  
		return mav;
	}
}
