package com.niit.springwithjdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.niit.springwithjdbc.model.Customer;



public class Sbiimpl implements SBI
{
	static Connection con=null;
	public static Connection getConenction()
	{
		try {
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test3","sa","sa");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return con;
	}

	public boolean addaccount(Customer customer)      //  name   acnum   bal  pin  city
	{

		
		boolean b=false;
		con=Sbiimpl.getConenction();
		int i=0;
		try {
		PreparedStatement pstmt=con.prepareStatement("insert into customer values(?,?,?,?,?)");
		pstmt.setString(1, customer.getAcnum());
		pstmt.setDouble(2, customer.getBal());
		pstmt.setString(3, customer.getCity());
		pstmt.setString(4, customer.getName());
		pstmt.setInt(5, customer.getPin());
	
		i=pstmt.executeUpdate();
		if(i>0)
			b=true;
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}

	public boolean validation(Customer customer)
	{
		boolean b=false;
		ResultSet rs=null;
		con=Sbiimpl.getConenction();
		try {
		Statement s=con.createStatement();
		rs=s.executeQuery("select pin from customer where pin='"+customer.getPin()+"'and acnum='"+customer.getAcnum()+"'");
		if(rs.next())
		{
			b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}

	public boolean deposite() {
		
		return false;
	}

	public boolean withdraw() {
		
		return false;
	}

	public Double balEnquiry() {
		
		return null;
	}
	

}
