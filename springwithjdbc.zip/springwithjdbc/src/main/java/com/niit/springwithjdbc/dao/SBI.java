package com.niit.springwithjdbc.dao;

import com.niit.springwithjdbc.model.Customer;

public interface SBI 
{
	
	public boolean addaccount(Customer customer);
	public boolean validation(Customer customer);
	public boolean deposite();
	public boolean withdraw();
	public Double balEnquiry();
}
