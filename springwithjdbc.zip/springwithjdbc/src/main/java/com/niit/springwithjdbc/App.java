package com.niit.springwithjdbc;

import com.niit.springwithjdbc.controller.Controller;

public class App 
{
    public static void main( String[] args )
    {
      new Controller();
      
    }
}
