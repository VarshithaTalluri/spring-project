package com.niit.springwithjdbc.controller;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.niit.springwithjdbc.dao.Sbiimpl;
import com.niit.springwithjdbc.model.Customer;

public class Controller
{
	Scanner s=new Scanner(System.in);
	 ApplicationContext ac=null;
     public Controller()
     {
    	ac=new ClassPathXmlApplicationContext("spring.xml");
    	System.out.println("1. create account");
    	System.out.println("2. validation ");
    	int opt=s.nextInt();
    	if(opt==1)
    	{
    		setCustomerDetails();
    	}
    	else if(opt==2)
    	{
    	setLoginDetails();
    	}
    	
     }
     public void setCustomerDetails()
     {
    	 boolean b=false;
    	 Customer c=new Customer();
    	 System.out.println("Enter account number");
    	 c.setAcnum(s.next());
    	 System.out.println("Enter account Bal");
    	 
    	 c.setBal(s.nextDouble());
    	 System.out.println("Enter city");
    	 
    	 c.setCity(s.next());
    	 System.out.println("Enter Name");
    	 
    	 c.setName(s.next());
    	 System.out.println("Enter pin");
    	 
    	 c.setPin(s.nextInt());
    	 b=new Sbiimpl().addaccount(c);
    	 if(b)
    	 {
    		 System.out.println("account created successfully");
    	 }
    	 else 
    	 {
    		 System.out.println("error");
    	 }
     }
     public void  setLoginDetails()
     {
    	 boolean b=false;
    	 Customer c=new Customer();
    	 System.out.println("Ennter account number");
    	 c.setAcnum(s.next());
    	 
    	 	 System.out.println("Enter pin");
    	 	 c.setPin(s.nextInt());
    	 	b=new Sbiimpl().validation(c);
    	 if(b)
    	 {
    		 System.out.println("valid user");
    	 }
    	 else
    	 {
    		 System.out.println("invalid user");
    	 }
     }
}
