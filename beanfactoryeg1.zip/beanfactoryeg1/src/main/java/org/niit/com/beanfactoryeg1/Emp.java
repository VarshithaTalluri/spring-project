package org.niit.com.beanfactoryeg1;

public class Emp 
{

}
