package org.niit.com.beanfactoryeg1;

public class Car 
{
  public void move()
 {
	 System.out.println("this is car class method");
 }
}
